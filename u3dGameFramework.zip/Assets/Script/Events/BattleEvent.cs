﻿ 
public static class BattleEvent
{

	/// <summary>
	/// 战斗开始
	/// </summary>
	public const string START = "battle_start";

	public const string ATTACK = "battle_acttack";


}
 