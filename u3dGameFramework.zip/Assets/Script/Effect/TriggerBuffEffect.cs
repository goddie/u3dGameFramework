 
using System;
 
public class TriggerBuffEffect : IEffect
{
//	BuffSkill buff = new BuffSkill (){
//
//	}


//	public List<IEffect> getEffects()
//	{
//		return new List().add(new ChangSheepEffect()).add(new PropChangeEffect()); 
//	}
//	
//	
//	public void cast(BattleAgent target){
//		int time = 3000;//3秒
//		target.addBuff(buff,time);
//	}

	public void cast (BattleAgent target)
	{
		throw new NotImplementedException ();
	}

	public void reverse ()
	{
		throw new NotImplementedException ();
	}
}