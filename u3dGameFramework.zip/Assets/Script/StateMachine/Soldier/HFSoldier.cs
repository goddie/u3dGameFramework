﻿using System;

/// <summary>
/// 黑风
/// </summary>
public class HFSoldier : EnemySoldier
{

}
