using System;

public class MajorBaseState : BaseState
{
	public MajorBaseState ()
	{
		this.StateType = StateType.Major;
	}
}