using System;

public class SubBaseState : BaseState
{
	public SubBaseState ()
	{
		this.StateType = StateType.Sub;
	}
}