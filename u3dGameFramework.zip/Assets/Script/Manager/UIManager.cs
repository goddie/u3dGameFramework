using System;
/// <summary>
/// User interface manager.
/// </summary>
public class UIManager
{
	public UIManager ()
	{
	}
}
