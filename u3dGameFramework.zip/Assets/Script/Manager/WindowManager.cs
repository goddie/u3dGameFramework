using System;
/// <summary>
/// 窗口管理
/// </summary>
public class WindowManager
{
	public WindowManager ()
	{
	}
}
